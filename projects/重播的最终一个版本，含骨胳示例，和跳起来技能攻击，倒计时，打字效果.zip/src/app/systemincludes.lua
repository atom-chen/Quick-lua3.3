
package.loaded["config"] = nil
require("config")

package.loaded["cocos.init"] = nil
require("cocos.init")

package.loaded["framework.init"] = nil
require("framework.init")
