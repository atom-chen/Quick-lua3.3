--
-- Author: wzg
-- Date: 2014-12-23 13:00:49
--
   
if device.platform == "ipad" then
    print("(######### ipad platform begin #########")
	playerPosition = { 
		['p1'] = { x = 330,y = 130},
		['p2'] = { x = 315,y = 0},
		['p3'] = { x = 300,y = -130},
		['p4'] = { x = 220,y = 130},
		['p5'] = { x = 205,y = 0},
		['p6'] = { x = 190,y = 130},
		['p7'] = { x = 70,y = 70}
	}
	npcPosition = { 
		['p1'] = { x = 330,y = 130},
		['p2'] = { x = 315,y = 0},
		['p3'] = { x = 300,y = -130},
		['p4'] = { x = 220,y = 130},
		['p5'] = { x = 205,y = 0},
		['p6'] = { x = 190,y = 130},
		['p7'] = { x = 70,y = 70}
	}
    print("(######### ipad platform end #########")
else
  	print("######### phone platform begin #########")
	playerPosition = { 
		['p1'] = { x = 380,y = 140},
		['p2'] = { x = 340,y = 0},
		['p3'] = { x = 300,y = -140},
		['p4'] = { x = 220,y = 140},
		['p5'] = { x = 180,y = 0},
		['p6'] = { x = 140,y = -140},
		['p7'] = { x = 70,y = 70}
	}

	npcPosition = { 
		['p1'] = { x = 380,y = 140},
		['p2'] = { x = 340,y = 0},
		['p3'] = { x = 300,y = -140},
		['p4'] = { x = 220,y = 140},
		['p5'] = { x = 180,y = 0},
		['p6'] = { x = 140,y = -140},
		['p7'] = { x = 70,y = 70}
	}

	print("######### phone platform end #########")
end






dump(playerPosition.p1)
