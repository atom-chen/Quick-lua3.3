--
-- Author: wzg
-- Date: 2038-01-02 00:36:42
--

-- for button click to scale
BUTTON_SCALE = 1.2



